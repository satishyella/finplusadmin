<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-06 18:16:53 --> 404 Page Not Found: Catalog/product_lookup
