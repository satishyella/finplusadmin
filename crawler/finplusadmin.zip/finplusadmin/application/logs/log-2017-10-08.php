<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-08 08:58:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
ERROR - 2017-10-08 08:58:42 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
ERROR - 2017-10-08 08:59:24 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 44
ERROR - 2017-10-08 08:59:42 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
ERROR - 2017-10-08 08:59:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
ERROR - 2017-10-08 09:01:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
ERROR - 2017-10-08 14:55:18 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 14:55:23 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 14:55:29 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 14:58:33 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:23:52 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:25:06 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:25:23 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:25:51 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:25:58 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:26:08 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:26:12 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-08 15:26:21 --> 404 Page Not Found: Vet/images
