<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-09 17:27:04 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-09 18:04:31 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-09 18:04:35 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-09 18:04:48 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-09 18:05:00 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-09 18:05:12 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-09 18:14:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
