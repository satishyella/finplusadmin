<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-18 09:24:09 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-18 09:24:36 --> 404 Page Not Found: Vet/images
