<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-19 15:42:09 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-19 15:42:24 --> 404 Page Not Found: Vet/images
