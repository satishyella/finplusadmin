<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-21 11:14:34 --> 404 Page Not Found: Vet/images
ERROR - 2017-10-21 11:18:08 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:10 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:04 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:29 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:29 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:29 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:20:29 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:21:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:21:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:23:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-21 11:26:05 --> Severity: Notice --> Undefined variable: main C:\xampp\htdocs\vetadmin\application\views\vet\doctor_template.php 128
ERROR - 2017-10-21 11:27:06 --> 404 Page Not Found: Vet/graph.html
ERROR - 2017-10-21 11:32:05 --> Severity: Notice --> Undefined index: parentname C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 24
ERROR - 2017-10-21 11:32:05 --> Severity: Notice --> Undefined index: parentname C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 24
ERROR - 2017-10-21 11:32:12 --> Severity: Notice --> Undefined index: parent_name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 24
ERROR - 2017-10-21 11:32:12 --> Severity: Notice --> Undefined index: parent_name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 24
ERROR - 2017-10-21 11:33:29 --> Severity: Notice --> Undefined index: vet_Name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 25
ERROR - 2017-10-21 11:33:29 --> Severity: Notice --> Undefined index: vet_Name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 25
ERROR - 2017-10-21 11:34:36 --> Severity: Notice --> Undefined index: pet_name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 25
ERROR - 2017-10-21 11:34:36 --> Severity: Notice --> Undefined index: pet_name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 25
ERROR - 2017-10-21 11:35:07 --> Severity: Notice --> Undefined index: pet_name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 25
ERROR - 2017-10-21 11:35:07 --> Severity: Notice --> Undefined index: pet_name C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 25
ERROR - 2017-10-21 11:40:18 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:40:18 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:40:18 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:40:18 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:40:42 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:40:42 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:40:42 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:40:42 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:04 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:04 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:04 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:04 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:25 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:25 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:25 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:41:25 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:42:04 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:42:04 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:42:04 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:42:04 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\dashboard.php 29
ERROR - 2017-10-21 11:49:28 --> 404 Page Not Found: Vet/graph.html
ERROR - 2017-10-21 12:13:21 --> 404 Page Not Found: Login/index
ERROR - 2017-10-21 12:14:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-21 12:14:20 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:14:24 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:14:42 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:14:44 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:14:50 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:14:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-21 12:15:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-21 12:15:21 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:15:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-21 12:15:22 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:15:24 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:15:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-21 12:15:26 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:15:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:15:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-21 12:15:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-21 12:15:32 --> 404 Page Not Found: Assets/img
