<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/css
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:21 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-25 14:11:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-25 14:11:27 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:11:27 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:12:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-25 14:12:55 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:13:24 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:13:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-25 14:13:26 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:13:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:13:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-25 14:13:34 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:15:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-25 14:15:21 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:16:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-25 14:16:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:16:35 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-25 14:16:35 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-25 14:16:53 --> 404 Page Not Found: Assets/img
