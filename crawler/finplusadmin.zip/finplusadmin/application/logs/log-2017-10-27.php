<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/css
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/css
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:35:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:36:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:36:41 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-27 05:37:01 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:37:01 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-27 05:37:01 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:37:13 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:37:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:37:24 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-27 05:37:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-27 05:37:36 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-27 05:39:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
ERROR - 2017-10-27 05:39:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-27 05:39:51 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-27 05:40:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
ERROR - 2017-10-27 05:40:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 10
