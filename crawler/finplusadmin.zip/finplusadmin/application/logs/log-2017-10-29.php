<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-29 05:59:36 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 05:59:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 05:59:49 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 05:59:59 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:05 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:00:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:26 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:35 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:38 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:41 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:44 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 06:00:49 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:00:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 06:00:59 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:01:12 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:02:17 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:02:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:02:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:02:36 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:02:38 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:02:40 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:02:43 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:03:30 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:03:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:03:35 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:03:48 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:04:01 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:04:03 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 06:04:03 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:04:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 06:04:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:04:31 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:05:57 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:05:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 06:05:57 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:05:57 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:06:07 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:06:07 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:13:49 --> Severity: Notice --> Undefined variable: salt C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 38
ERROR - 2017-10-29 06:17:48 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 06:17:49 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:17:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\vetadmin\application\models\Vet_model.php 11
ERROR - 2017-10-29 06:18:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 06:18:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 06:26:56 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:28:54 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:28:54 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:30:44 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:30:44 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:30:53 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:30:53 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:31:08 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:31:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:31:25 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:25 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:25 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:26 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:32:26 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:46 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:32:48 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:32:51 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:32:51 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 06:33:18 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 06:33:19 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 15:29:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 15:29:45 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:29:51 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:30:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:31:32 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:31:44 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:33:40 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:34:36 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:34:52 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:35:25 --> Severity: Error --> Call to undefined function userdata() C:\xampp\htdocs\vetadmin\application\views\vet\doctor_template.php 106
ERROR - 2017-10-29 15:35:45 --> Severity: Error --> Call to undefined function userdata() C:\xampp\htdocs\vetadmin\application\views\vet\doctor_template.php 106
ERROR - 2017-10-29 15:35:48 --> Severity: Error --> Call to undefined function userdata() C:\xampp\htdocs\vetadmin\application\views\vet\doctor_template.php 106
ERROR - 2017-10-29 15:35:49 --> Severity: Error --> Call to undefined function userdata() C:\xampp\htdocs\vetadmin\application\views\vet\doctor_template.php 106
ERROR - 2017-10-29 15:36:12 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:38:22 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:38:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:38:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:40:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'post insulin,bloodGlucoseValue FROM `pet_vet_encounter` where vet_ID=1 and pet_I' at line 1 - Invalid query: SELECT encounter_Date,pre_post_insulin as pre post insulin,bloodGlucoseValue FROM `pet_vet_encounter` where vet_ID=1 and pet_ID=1 and parent_ID=1 limit 5
ERROR - 2017-10-29 15:40:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:41:05 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:41:26 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:41:39 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:41:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 15:41:57 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:42:58 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:43:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:43:53 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 15:44:11 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 15:46:17 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:46:23 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 15:46:23 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 15:46:52 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:47:53 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:47:59 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:48:05 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:48:10 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:48:51 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:49:17 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:49:25 --> 404 Page Not Found: Vet/changepassword
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 15
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 15
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 15
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 20
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 20
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 20
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 23
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 23
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 23
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 27
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 27
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 27
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 31
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: pet C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 31
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined index: parent C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 31
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined variable: graph C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 46
ERROR - 2017-10-29 15:51:51 --> Severity: Notice --> Undefined variable: tabledata C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 113
ERROR - 2017-10-29 15:51:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 113
ERROR - 2017-10-29 15:51:52 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:53:03 --> Severity: Notice --> Undefined variable: tabledata C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 43
ERROR - 2017-10-29 15:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\vetadmin\application\views\vet\passwordchange.php 43
ERROR - 2017-10-29 15:53:03 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:53:42 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:54:17 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:54:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:55:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:55:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:55:40 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:55:54 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:56:21 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:56:43 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:56:50 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:57:02 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 15:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 15:57:11 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 15:57:11 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:57:43 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:57:52 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 15:58:01 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 15:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2017-10-29 15:59:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-10-29 15:59:34 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:00:13 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:00:14 --> 404 Page Not Found: Vet/chnagepassword
ERROR - 2017-10-29 16:00:17 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:00:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:00:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:02:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:02:22 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:03:51 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 149
ERROR - 2017-10-29 16:04:05 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:04:10 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:04:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:05:26 --> Severity: Notice --> Undefined property: Vet::$post C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 151
ERROR - 2017-10-29 16:05:26 --> Severity: Error --> Call to a member function input() on null C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 151
ERROR - 2017-10-29 16:06:36 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 151
ERROR - 2017-10-29 16:06:56 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 152
ERROR - 2017-10-29 16:07:19 --> Severity: Notice --> Undefined property: Vet::$post C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 150
ERROR - 2017-10-29 16:07:19 --> Severity: Error --> Call to a member function input() on null C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 150
ERROR - 2017-10-29 16:07:45 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\vetadmin\application\controllers\Vet.php 152
ERROR - 2017-10-29 16:08:14 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:08:18 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:08:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:08:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:08:56 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-10-29 16:08:56 --> 404 Page Not Found: Assets/img
ERROR - 2017-10-29 16:09:00 --> 404 Page Not Found: Assets/img
