<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-02 07:24:20 --> 404 Page Not Found: /index
ERROR - 2017-11-02 07:38:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and active_flag='1'' at line 1 - Invalid query: select vm.vet_ID,vet_name,pm.parent_ID,parent_Name,vpr.pet_ID,pet_Name,pet_gender,pet_breed,pet_dob from vet_master vm left join vet_parent_relation vpr on vm.vet_ID=vpr.vet_ID left join parent_master pm on pm.parent_ID=vpr.parent_ID left join pet_detail pd on pd.pet_ID=vpr.pet_ID where vm.vet_ID= and active_flag='1' 
ERROR - 2017-11-02 07:39:01 --> 404 Page Not Found: Admin/img
ERROR - 2017-11-02 07:50:45 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-02 08:11:14 --> 404 Page Not Found: Vet/index
