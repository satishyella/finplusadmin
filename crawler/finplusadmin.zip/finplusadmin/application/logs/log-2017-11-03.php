<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-03 07:31:42 --> 404 Page Not Found: /index
ERROR - 2017-11-03 08:12:14 --> Severity: Notice --> Use of undefined constant base - assumed 'base' C:\xampp\htdocs\finplusadmin\application\views\admin\signin.php 10
ERROR - 2017-11-03 08:12:14 --> Severity: Error --> Call to undefined function url() C:\xampp\htdocs\finplusadmin\application\views\admin\signin.php 10
ERROR - 2017-11-03 08:13:11 --> Severity: Notice --> Use of undefined constant base - assumed 'base' C:\xampp\htdocs\finplusadmin\application\views\admin\signin.php 12
ERROR - 2017-11-03 08:13:11 --> Severity: Error --> Call to undefined function url() C:\xampp\htdocs\finplusadmin\application\views\admin\signin.php 12
ERROR - 2017-11-03 08:13:11 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:13:29 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:13:32 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:32 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:32 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:32 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:13:32 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:14:46 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:15:30 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/font
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:16:01 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/font
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:17:03 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/font
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:18:23 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/font
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:18:55 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:19:11 --> 404 Page Not Found: Asssets/css
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Assets/font
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Asssets/js
ERROR - 2017-11-03 08:19:43 --> 404 Page Not Found: Asssets/icheck.min.js
ERROR - 2017-11-03 08:20:00 --> 404 Page Not Found: Assets/icheck.min.js
ERROR - 2017-11-03 08:20:00 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:20:00 --> 404 Page Not Found: Assets/font
ERROR - 2017-11-03 08:20:00 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:20:02 --> 404 Page Not Found: Assets/icheck.min.js
ERROR - 2017-11-03 08:20:16 --> 404 Page Not Found: Assets/font
ERROR - 2017-11-03 08:20:16 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:20:16 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:20:37 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:20:37 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:20:37 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:22:00 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:00 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:03 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:05 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:05 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:22:05 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:39 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:40 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:22:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:23:54 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:23:54 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 08:24:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:28:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:28:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:28:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:29:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:29:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:29:18 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:29:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:29:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:30:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:30:35 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:30:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:31:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:31:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 08:32:37 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:47:40 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:47:41 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:47:41 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:47:42 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:47:42 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 09:47:42 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 09:47:42 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 09:47:43 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:47:43 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:50:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:50:50 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:50:50 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:52:07 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:52:14 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:52:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:52:14 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:53:08 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 09:53:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:09 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:09 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:53:09 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:53:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:11 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:11 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:53:11 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:53:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:53:55 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:55 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:53:55 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:53:55 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:58 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:58 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 09:53:58 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:53:58 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:56:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:56:00 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:56:00 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:56:02 --> 404 Page Not Found: Assets/jquery.slimscroll.min.js
ERROR - 2017-11-03 09:56:02 --> 404 Page Not Found: Assets/bower_components
ERROR - 2017-11-03 09:56:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 09:57:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 10:20:52 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-03 10:21:43 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-03 10:21:47 --> 404 Page Not Found: /index
ERROR - 2017-11-03 10:27:29 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-03 10:27:36 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:27:38 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:28:11 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:28:14 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 10:28:47 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:28:49 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 10:29:11 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:29:13 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 10:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 10:29:30 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:29:33 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 10:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 10:29:49 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:30:09 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 10:30:13 --> 404 Page Not Found: Assetsjs/adminlte.min.js
ERROR - 2017-11-03 11:31:20 --> 404 Page Not Found: /index
ERROR - 2017-11-03 11:31:24 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 11:33:51 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 11:33:53 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 11:34:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 11:35:42 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 11:36:00 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 11:38:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 11:40:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 11:41:34 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 16:50:21 --> 404 Page Not Found: /index
ERROR - 2017-11-03 16:50:52 --> 404 Page Not Found: Vet/login
ERROR - 2017-11-03 16:51:08 --> 404 Page Not Found: Vet/login
ERROR - 2017-11-03 16:54:04 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 16:54:08 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 16:56:17 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 16:56:17 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 16:57:15 --> 404 Page Not Found: Vet/logout
ERROR - 2017-11-03 16:58:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 16:58:13 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 16:58:16 --> 404 Page Not Found: Vet/logout
ERROR - 2017-11-03 17:03:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-03 17:04:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-03 17:04:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-03 17:04:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-03 17:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-03 17:06:29 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 52
ERROR - 2017-11-03 17:06:29 --> Query error: Table 'finplus.vet_master' doesn't exist - Invalid query: select vm.vet_ID,vet_name,pm.parent_ID,parent_Name,vpr.pet_ID,pet_Name,pet_gender,pet_breed,pet_dob from vet_master vm left join vet_parent_relation vpr on vm.vet_ID=vpr.vet_ID left join parent_master pm on pm.parent_ID=vpr.parent_ID left join pet_detail pd on pd.pet_ID=vpr.pet_ID where vm.vet_ID=1 and active_flag='1' 
ERROR - 2017-11-03 17:06:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-03 17:07:19 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 52
ERROR - 2017-11-03 17:07:19 --> Query error: Table 'finplus.vet_master' doesn't exist - Invalid query: select vm.vet_ID,vet_name,pm.parent_ID,parent_Name,vpr.pet_ID,pet_Name,pet_gender,pet_breed,pet_dob from vet_master vm left join vet_parent_relation vpr on vm.vet_ID=vpr.vet_ID left join parent_master pm on pm.parent_ID=vpr.parent_ID left join pet_detail pd on pd.pet_ID=vpr.pet_ID where vm.vet_ID=1 and active_flag='1' 
ERROR - 2017-11-03 17:08:53 --> Severity: Error --> Call to undefined method Admin_model::getpetdetails() C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 73
ERROR - 2017-11-03 17:09:03 --> Severity: Notice --> Undefined index: parent_Name C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 24
ERROR - 2017-11-03 17:09:03 --> Severity: Notice --> Undefined index: pet_Name C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 25
ERROR - 2017-11-03 17:09:03 --> Severity: Notice --> Undefined index: pet_breed C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 26
ERROR - 2017-11-03 17:09:03 --> Severity: Notice --> Undefined index: pet_dob C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 27
ERROR - 2017-11-03 17:09:03 --> Severity: Notice --> Undefined index: pet_gender C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 28
ERROR - 2017-11-03 17:09:03 --> Severity: Notice --> Undefined index: pet_ID C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 29
ERROR - 2017-11-03 17:09:03 --> Severity: Notice --> Undefined index: parent_ID C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 29
ERROR - 2017-11-03 17:09:03 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-11-03 17:09:04 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:10:18 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:10:54 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:11:13 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-03 17:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-03 17:14:04 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 26
ERROR - 2017-11-03 17:14:05 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:14:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:17:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:19:03 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:21:09 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 26
ERROR - 2017-11-03 17:21:39 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:22:08 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:23:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:23:31 --> Severity: Notice --> Undefined property: Admin::$admin_model C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 173
ERROR - 2017-11-03 17:23:31 --> Severity: Error --> Call to a member function up_sts_adminuser() on null C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 173
ERROR - 2017-11-03 17:23:56 --> Severity: Notice --> Undefined property: Admin::$measures_db C:\xampp\htdocs\finplusadmin\system\core\Model.php 77
ERROR - 2017-11-03 17:23:56 --> Severity: Error --> Call to a member function where() on null C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 107
ERROR - 2017-11-03 17:24:10 --> Severity: Notice --> Undefined variable: sno C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 107
ERROR - 2017-11-03 17:24:10 --> Severity: Notice --> Undefined property: Admin::$measures_db C:\xampp\htdocs\finplusadmin\system\core\Model.php 77
ERROR - 2017-11-03 17:24:10 --> Severity: Error --> Call to a member function update() on null C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 109
ERROR - 2017-11-03 17:24:27 --> Severity: Notice --> Undefined property: Admin::$measures_db C:\xampp\htdocs\finplusadmin\system\core\Model.php 77
ERROR - 2017-11-03 17:24:27 --> Severity: Error --> Call to a member function update() on null C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 109
ERROR - 2017-11-03 17:24:38 --> 404 Page Not Found: Measures_admin/measures
ERROR - 2017-11-03 17:25:00 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:25:02 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:25:04 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-03 17:25:08 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:25:32 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:25:35 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:25:58 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:26:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:26:39 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:27:02 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:28:48 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:28:56 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:29:07 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:29:45 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:30:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:30:42 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:31:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:31:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:31:41 --> 404 Page Not Found: Measures_admin/measures
ERROR - 2017-11-03 17:32:03 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:32:05 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:32:07 --> Severity: Warning --> Missing argument 3 for Admin::act_inact_comp() C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 169
ERROR - 2017-11-03 17:32:07 --> Severity: Notice --> Undefined variable: token C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 171
ERROR - 2017-11-03 17:32:11 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:32:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:32:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:32:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:34:43 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:34:45 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:34:50 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:35:36 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-03 17:35:38 --> 404 Page Not Found: Assets/img
