<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-04 04:46:08 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-04 04:46:17 --> 404 Page Not Found: /index
ERROR - 2017-11-04 04:46:28 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 52
ERROR - 2017-11-04 04:46:28 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 14
ERROR - 2017-11-04 04:46:28 --> 404 Page Not Found: Measures_admin/images
ERROR - 2017-11-04 04:46:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-04 04:46:31 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 14
ERROR - 2017-11-04 04:46:31 --> 404 Page Not Found: Measures_admin/images
ERROR - 2017-11-04 04:46:32 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-04 04:46:45 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 14
ERROR - 2017-11-04 04:46:45 --> 404 Page Not Found: Measures_admin/images
ERROR - 2017-11-04 04:46:46 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-04 04:47:10 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 14
ERROR - 2017-11-04 04:47:10 --> 404 Page Not Found: Measures_admin/images
ERROR - 2017-11-04 04:47:11 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-04 04:47:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-04 04:47:16 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-04 04:47:36 --> 404 Page Not Found: Measures_admin/images
ERROR - 2017-11-04 04:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-04 04:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-04 04:47:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-04 04:48:26 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-04 04:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-04 04:48:26 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-04 04:49:47 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-04 04:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-04 04:49:47 --> 404 Page Not Found: Assets/img
