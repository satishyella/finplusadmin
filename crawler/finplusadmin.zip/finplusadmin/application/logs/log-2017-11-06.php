<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-06 14:51:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-06 14:52:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\finplusadmin\application\controllers\Admin.php 52
ERROR - 2017-11-06 14:52:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 14:52:44 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 14:53:46 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 14:54:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 14:56:08 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 14:56:16 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 14:56:16 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 14:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 14:56:33 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 14:56:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 14:57:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 14:57:52 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:23:56 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:24:53 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:34:54 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 32
ERROR - 2017-11-06 15:35:07 --> Severity: Parsing Error --> syntax error, unexpected 'e' (T_STRING), expecting variable (T_VARIABLE) C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 32
ERROR - 2017-11-06 15:35:16 --> Severity: Parsing Error --> syntax error, unexpected 'log_message' (T_STRING), expecting '{' C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 33
ERROR - 2017-11-06 15:35:51 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 42
ERROR - 2017-11-06 15:36:05 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:37:38 --> Severity: Notice --> Undefined index: cid C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 33
ERROR - 2017-11-06 15:37:39 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:42:37 --> Severity: Notice --> Undefined index: cid C:\xampp\htdocs\finplusadmin\application\views\admin\dashboard.php 33
ERROR - 2017-11-06 15:42:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:43:06 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:44:01 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:44:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:44:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:48:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:48:37 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:48:39 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:48:43 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:48:46 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 15:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 15:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 15:49:47 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:51:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:51:36 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 15:51:36 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 15:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 15:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 15:52:38 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:52:55 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:55:28 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 44
ERROR - 2017-11-06 15:55:42 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 44
ERROR - 2017-11-06 15:55:45 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 44
ERROR - 2017-11-06 15:56:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 45
ERROR - 2017-11-06 15:57:29 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::num_rows() C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 46
ERROR - 2017-11-06 15:59:01 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:59:11 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:59:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:59:30 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:59:44 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 15:59:54 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:00:51 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:02:55 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:03:03 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:03:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:03:38 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:03:53 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:04:04 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:04:41 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:04:49 --> 404 Page Not Found: Vet/dashboard
ERROR - 2017-11-06 16:04:52 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:05:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:05:53 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:05:55 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:05:56 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:06:10 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:06:11 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:06:11 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:06:13 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:06:13 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:06:13 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:06:25 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:06:25 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:06:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:06:35 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:06:35 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:06:35 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:06:57 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:07:02 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:07:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:07:18 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:07:18 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:08:19 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:08:20 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:08:20 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:08:35 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:08:35 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:08:50 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:08:52 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:50:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:50:43 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:50:43 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 16:51:29 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 16:51:29 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:51:32 --> 404 Page Not Found: Vet/changepassword
ERROR - 2017-11-06 16:52:07 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:52:27 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:56:46 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:58:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:58:27 --> 404 Page Not Found: Vet/logout
ERROR - 2017-11-06 16:58:41 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:58:44 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:58:47 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-06 16:59:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:59:20 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 16:59:28 --> 404 Page Not Found: Vet/changepassword
ERROR - 2017-11-06 17:00:08 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:01:50 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:02:14 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:02:20 --> Query error: Table 'finplus.user' doesn't exist - Invalid query: UPDATE `user` SET `pswd` = '3e38c09f282ec46202762711b649e37c', `updated_by` = NULL
WHERE `user_ID` IS NULL
ERROR - 2017-11-06 17:03:08 --> Query error: Table 'finplus.user' doesn't exist - Invalid query: UPDATE `user` SET `pswd` = '3e38c09f282ec46202762711b649e37c'
WHERE `sno` IS NULL
ERROR - 2017-11-06 17:03:42 --> Query error: Table 'finplus.user' doesn't exist - Invalid query: UPDATE `user` SET `pswd` = '3e38c09f282ec46202762711b649e37c'
WHERE `sno` = '1'
ERROR - 2017-11-06 17:04:13 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:04:34 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:06:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:06:19 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:06:19 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:06:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:06:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:07:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:07:57 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:08:06 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:08:06 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:08:19 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:08:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:08:31 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:08:49 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:13:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 76
ERROR - 2017-11-06 17:13:59 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-06 17:14:15 --> 404 Page Not Found: Vet/index
ERROR - 2017-11-06 17:15:42 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 11
ERROR - 2017-11-06 17:16:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:16:41 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:16:41 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:16:46 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:18:20 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:19:08 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:19:09 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:19:16 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:19:21 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:20:06 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:20:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:20:53 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:21:04 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:21:10 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:21:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:21:27 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:21:30 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:21:32 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:26:10 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:26:15 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:26:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:26:22 --> Severity: Notice --> Undefined index: cik C:\xampp\htdocs\finplusadmin\application\views\admin\forms.php 38
ERROR - 2017-11-06 17:26:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:26:32 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:26:59 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:27:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:28:38 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting '(' C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 74
ERROR - 2017-11-06 17:28:58 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting variable (T_VARIABLE) C:\xampp\htdocs\finplusadmin\application\models\Admin_model.php 74
ERROR - 2017-11-06 17:29:08 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:29:13 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:29:22 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:29:33 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:30:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:30:23 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:30:26 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:30:27 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:30:27 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:31:53 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:31:53 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:32:21 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:32:23 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:32:25 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:32:48 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:32:51 --> 404 Page Not Found: Admin/form
ERROR - 2017-11-06 17:33:27 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:33:32 --> 404 Page Not Found: Admin/form
ERROR - 2017-11-06 17:33:35 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:34:02 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:34:19 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:34:22 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:34:27 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:34:40 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:34:47 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:37:28 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:37:30 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:37:32 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:37:35 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:37:57 --> 404 Page Not Found: Assets/css
ERROR - 2017-11-06 17:37:57 --> 404 Page Not Found: Assets/js
ERROR - 2017-11-06 17:37:57 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:38:05 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:38:07 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:38:14 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:38:20 --> 404 Page Not Found: Assets/img
ERROR - 2017-11-06 17:38:28 --> 404 Page Not Found: Assets/img
